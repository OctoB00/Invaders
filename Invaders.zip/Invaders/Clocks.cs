﻿using System;
using System.Collections.Generic;
using System.Text;
using SFML.Graphics;
using SFML.System;
using SFML.Window;

namespace Invaders
{
    public class Clocks
    {
        public Clock DifficultyTimer;
        public Clock spawnTimer;
        public Clock scoreTimer;
        public void Start()
        {
            DifficultyTimer = new Clock();
            spawnTimer = new Clock();
            scoreTimer = new Clock();
        }
        public void Reset()
        {
            DifficultyTimer.Restart();
            spawnTimer.Restart();
            scoreTimer.Restart();
        }
    }
}
