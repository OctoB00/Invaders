﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using SFML.Graphics;
using SFML.System;
using SFML.Window;

namespace Invaders
{
    public class EnemyShip : Entity
    {
        private readonly Sprite sprite;
        private Vector2f velocity;
        private float rotation;
        private Clock shootTimer = new Clock();
        private int shoot = 2;
        public EnemyShip()
        {
            sprite = new Sprite();
        }
        public override void Load(Textures textures)
        {
            sprite.Texture = textures.GetTexture("Enemyship.png");
            sprite.Origin = (Vector2f)sprite.Texture.Size * 0.5f;
        }
        public override Vector2f Position
        {
            get => sprite.Position;
            set => sprite.Position = value;
        }
        public override Vector2f Velocity
        {
            get => Velocity;
            set => velocity = value;
        }
        //public override float Rotation
        //{
        //    get;
        //    set;
        //}
        public bool HasShot()
        {
            if (shootTimer.ElapsedTime.AsSeconds() >= shoot)
            {
                shootTimer.Restart();
                return true;
            }
            else
            {
                return false;
            }
        }
        public void Shoot(Game game)
        {
            game.Spawn(new Bullet()
            {
                Position = this.Position,
                Velocity = velocity * 2f,
                Rotation = rotation
            });

        }
        public override float Radius => MathF.Max(sprite.Origin.X, sprite.Origin.Y);
        public override void Update(Game game, float deltaTime)
        {
            Vector2f newPos = Position + velocity * deltaTime;

            if (newPos.Y < -Radius) newPos.Y = Program.ScreenH + Radius;
            if (newPos.Y > Program.ScreenH + Radius) newPos.Y = -Radius;

            if (newPos.X - Radius < 0 || newPos.X + Radius > Program.ScreenW) velocity.X *= -1;
            else Position = newPos;

            if (velocity.X > 0) rotation = 75;
            if (velocity.X < 0) rotation = 115;
            if (velocity.X == 0) rotation = 90;
 
        }
        public override void Render(RenderTarget target)
        {
            sprite.Rotation = rotation;
            target.Draw(sprite);
        }
    }
}
