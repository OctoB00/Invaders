﻿using System;
using System.Collections.Generic;
using System.Text;
using SFML.Graphics;
using SFML.System;
using SFML.Window;

namespace Invaders
{
    public class EnemyShip : Entity
    {
        private readonly Sprite sprite;
        public EnemyShip()
        {
            sprite = new Sprite();
        }
        public override void Load(Textures textures)
        {
            sprite.Texture = textures.GetTexture("Enemyship.png");
            sprite.Origin = (Vector2f)sprite.Texture.Size * 0.5f;
        }
        public override Vector2f Position
        {
            get => sprite.Position;
            set => sprite.Position = value;
        }
        public override Vector2f Velocity
        {
            get;
            set;
        }
        public override float Rotation
        {
            get;
            set;
        }
        public override void Update(Game game, float deltaTime)
        {
            Vector2f newPos = Position + Velocity * deltaTime;
            Position = newPos;
        }
        public override void Render(RenderTarget target)
        {
            sprite.Rotation = Rotation;
            target.Draw(sprite);
        }
    }
}
