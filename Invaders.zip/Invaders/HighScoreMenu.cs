﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SFML.Graphics;
using SFML.System;
using SFML.Window;

namespace Invaders
{
    class HighScoreMenu
    {
        private Text HighScoreValue;
        private Text HighScoreHeader;
        private Text HighScoreButtonText;
        private readonly RectangleShape HighScoreButton;

        private const int FontSize = 35;
        private const int TitleSize = 75;
        private bool enterPressed, goBack;
        private Clock buttonDelay = new Clock();
        private const float buttonTime = 0.05f;
        private const int listMax = 10;

        public HighScoreMenu(Font font)
        {
            HighScoreValue = new Text("", font, FontSize);
            HighScoreHeader = new Text("", font, TitleSize);
            HighScoreButtonText = new Text("", font, FontSize);
            HighScoreButton = new RectangleShape(new Vector2f(200, 100));
        }
        private void OnKeyPressed(object sender, KeyEventArgs e)
        {
            switch (e.Code)
            {
                case Keyboard.Key.Enter: enterPressed = true; break;
            }
        }
        private void OnKeyReleased(object sender, KeyEventArgs e)
        {
            switch (e.Code)
            {
                case Keyboard.Key.Enter: enterPressed = false; break;
            }
        }
        public void OnScoreMenuSpawn(Window w)
        {
            w.KeyPressed += OnKeyPressed;
            w.KeyReleased += OnKeyReleased;
        }
        public void OnScoreMenuDespawn(Window w)
        {
            w.KeyPressed -= OnKeyPressed;
            w.KeyReleased -= OnKeyReleased;
        }
        public void HighScoreText(string[] scores, RenderTarget target)
        {
            HighScoreHeader.DisplayedString = "Highscores";
            HighScoreHeader.Position = new Vector2f(Program.ScreenW / 2, 20);
            HighScoreHeader.Origin = new Vector2f(HighScoreHeader.GetLocalBounds().Width / 2, HighScoreHeader.GetLocalBounds().Height / 2);

            HighScoreButtonText.DisplayedString = "Back";
            HighScoreButtonText.Position = HighScoreButton.Position + new Vector2f(30, -10);
            HighScoreButtonText.Origin = new Vector2f(HighScoreButtonText.GetLocalBounds().Width, HighScoreButtonText.GetLocalBounds().Height / 2);

            HighScoreButton.Position = new Vector2f(125, Program.ScreenH - 75);
            HighScoreButton.Origin = new Vector2f(HighScoreButton.GetLocalBounds().Width / 2, HighScoreButton.GetLocalBounds().Height / 2);

            List<string> ScoreList = new List<string>(scores);
            List<int> ScoreNumber = ScoreList.Select(int.Parse).ToList();
            ScoreNumber.Sort();
            ScoreNumber.Reverse();
            if (ScoreNumber.Count > 20)
            {
                ScoreNumber.Remove(ScoreNumber.Min());
            }
            
            float X;
            float Y;
            int line = 1;
            foreach (int score in ScoreNumber)
            {
                X = 150;
                Y = 100 + line * (HighScoreValue.GetLocalBounds().Height + 5);
                HighScoreValue.DisplayedString = $"{score}";
                HighScoreValue.Position = new Vector2f(X, Y);
                target.Draw(HighScoreValue);
                line++;
            }
            HighScoreButtonText.FillColor = Color.Black;
            HighScoreButton.FillColor = new Color(155, 155, 155);
            target.Draw(HighScoreHeader);
            target.Draw(HighScoreButton);
            target.Draw(HighScoreButtonText);
            if (enterPressed && buttonDelay.ElapsedTime.AsSeconds() > buttonTime)
            {
                buttonDelay.Restart();
                goBack = true;
            }
            else
            {
                goBack = false;
            }
        }
        public int GetHighestScore(string[] scores)
        {
            List<string> ScoreList = new List<string>(scores);
            List<int> ScoreNumber = ScoreList.Select(int.Parse).ToList();
            int max = ScoreNumber.Max();
            return max;
        }
        public bool ToMenu()
        {
            return goBack;
        }
    }
}
