﻿using System;
using System.Collections.Generic;
using System.Text;
using SFML.Graphics;
using SFML.System;
using SFML.Window;

namespace Invaders
{
    public class Bullet : Entity
    {
        private readonly Sprite sprite;

        public Bullet()
        {
            sprite = new Sprite();
        }
        public override Vector2f Position
        {
            get => sprite.Position;
            set => sprite.Position = value;
        }
        public override Vector2f Velocity
        {
            get;
            set;
        }
        public override float Rotation
        {
            get;
            set;
        }
        public Color color
        {
            get;
            set;
        }
        public override float Radius => MathF.Max(sprite.Origin.X, sprite.Origin.Y);
        public override void Load(Textures textures)
        {
            sprite.Texture = textures.GetTexture("bullet.png");
            sprite.Origin = (Vector2f)sprite.Texture.Size * 0.5f;
        }
        public override void Update(Game game, float deltaTime)
        {
            Position += Velocity * deltaTime;
            if (Position.X < -Radius || Position.X > Program.ScreenW + Radius
            || Position.Y < -Radius || Position.Y > Program.ScreenH + Radius)
            {
                game.Kill(this);
            }
        }
        public override void Render(RenderTarget target)
        {
            sprite.Rotation = Rotation;
            sprite.Color = color;
            target.Draw(sprite);
        }
    }
}
