﻿using System;
using System.Collections.Generic;
using System.Text;
using SFML.Graphics;
using SFML.System;
using SFML.Window;
using System.Linq;
using System.IO;

namespace Invaders
{
    public class Menu
    {
        private readonly RectangleShape button1;
        private readonly RectangleShape button2;
        private readonly RectangleShape button3;

        private Text buttonText1;
        private Text buttonText2;
        private Text buttonText3;
        private Text Title;

        private const int FontSize = 35;
        private const int TitleSize = 75;
        private static int currentButton = 1;
        private bool goUp, goDown, enterPressed;
        private Clock buttonDelay = new Clock();
        private const float buttonTime = 0.2f;

        public Menu(Font font)
        {
            button1 = new RectangleShape(new Vector2f(450, 150));
            button2 = new RectangleShape(new Vector2f(450, 150));
            button3 = new RectangleShape(new Vector2f(450, 150));

            buttonText1 = new Text("", font, FontSize);
            buttonText2 = new Text("", font, FontSize);
            buttonText3 = new Text("", font, FontSize);
            Title = new Text("", font, TitleSize);
        }
        private void OnKeyPressed(object sender, KeyEventArgs e)
        {
            switch (e.Code)
            {
                case Keyboard.Key.Up: goUp = true; break;
                case Keyboard.Key.Down: goDown = true; break;
                case Keyboard.Key.Enter: enterPressed = true; break;
            }
        }
        private void OnKeyReleased(object sender, KeyEventArgs e)
        {
            switch (e.Code)
            {
                case Keyboard.Key.Up: goUp = false; break;
                case Keyboard.Key.Down: goDown = false; break;
                case Keyboard.Key.Enter: enterPressed = false; break;
            }
        }
        public void OnMenuSpawn(Window w)
        {
            w.KeyPressed += OnKeyPressed;
            w.KeyReleased += OnKeyReleased;
        }
        public void OnMenuDespawn(Window w)
        {
            w.KeyPressed -= OnKeyPressed;
            w.KeyReleased -= OnKeyReleased;
        }
        public int MenuSelect()
        {
            if (currentButton == 1 && enterPressed)
            {
                return 1;
            }
            else if (currentButton == 2 && enterPressed /*&& buttonDelay.ElapsedTime.AsSeconds() > buttonTime*/)
            {
                //enterPressed = false;
                //buttonDelay.Restart();
                return 2;
            }
            else if (currentButton == 3 && enterPressed)
            {
                return 3;
            }
            else
            {
                return 4;
            }
        }
        public void UpdateMenu()
        {
            button1.Position = new Vector2f(Program.ScreenW / 2, 400 - button1.Origin.Y);
            button1.Origin = (Vector2f)button1.Size * 0.5f;

            button2.Position = new Vector2f(Program.ScreenW / 2, 650 - button2.Origin.Y);
            button2.Origin = (Vector2f)button2.Size * 0.5f;

            button3.Position = new Vector2f(Program.ScreenW / 2, 900 - button3.Origin.Y);
            button3.Origin = (Vector2f)button3.Size * 0.5f;

            buttonText1.DisplayedString = "Start Game";
            buttonText1.Position = button1.Position;
            buttonText1.Origin = new Vector2f(buttonText1.GetLocalBounds().Width / 2, buttonText1.GetLocalBounds().Height / 2);

            buttonText2.DisplayedString = "Highscores";
            buttonText2.Position = button2.Position;
            buttonText2.Origin = new Vector2f(buttonText2.GetLocalBounds().Width / 2, buttonText2.GetLocalBounds().Height / 2);

            buttonText3.DisplayedString = "Exit Game";
            buttonText3.Position = button3.Position;
            buttonText3.Origin = new Vector2f(buttonText3.GetLocalBounds().Width / 2, buttonText3.GetLocalBounds().Height / 2);

            Title.DisplayedString = "Invaders";
            Title.Position = new Vector2f(Program.ScreenW / 2, 100);
            Title.Origin = new Vector2f(Title.GetLocalBounds().Width / 2, Title.GetLocalBounds().Height / 2);

            if (currentButton == 1 && goDown && buttonDelay.ElapsedTime.AsSeconds() > buttonTime)
            {
                buttonDelay.Restart();
                currentButton = 2;
            }
            else if (currentButton == 2 && goDown && buttonDelay.ElapsedTime.AsSeconds() > buttonTime)
            {
                buttonDelay.Restart();
                currentButton = 3;
            }
            else if (currentButton == 3 && goDown && buttonDelay.ElapsedTime.AsSeconds() > buttonTime)
            {
                buttonDelay.Restart();
                currentButton = 1;
            }
            else if (currentButton == 1 && goUp && buttonDelay.ElapsedTime.AsSeconds() > buttonTime)
            {
                buttonDelay.Restart();
                currentButton = 3;
            }
            else if (currentButton == 2 && goUp && buttonDelay.ElapsedTime.AsSeconds() > buttonTime)
            {
                buttonDelay.Restart();
                currentButton = 1;
            }
            else if (currentButton == 3 && goUp && buttonDelay.ElapsedTime.AsSeconds() > buttonTime)
            {
                buttonDelay.Restart();
                currentButton = 2;
            }
        }
        public void RenderMenu(RenderTarget target)
        {
            switch (currentButton)
            {
                case 1: button1.FillColor = new Color(155, 155, 155); button2.FillColor = Color.White; button3.FillColor = Color.White; break;
                case 2: button2.FillColor = new Color(155, 155, 155); button1.FillColor = Color.White; button3.FillColor = Color.White; break;
                case 3: button3.FillColor = new Color(155, 155, 155); button1.FillColor = Color.White; button2.FillColor = Color.White; break;
            }
            buttonText1.FillColor = Color.Black;
            buttonText2.FillColor = Color.Black;
            buttonText3.FillColor = Color.Black;
            target.Draw(button1);
            target.Draw(button2);
            target.Draw(button3);
            target.Draw(buttonText1);
            target.Draw(buttonText2);
            target.Draw(buttonText3);
            target.Draw(Title);
        }
    }
}