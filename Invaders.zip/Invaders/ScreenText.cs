﻿using System;
using System.Collections.Generic;
using System.Text;
using SFML.Graphics;
using SFML.System;
using SFML.Window;

namespace Invaders
{
    public  class ScreenText
    {
        private Text ScoreText;
        private Text HealthText;
        private Text DeathText1;
        private Text DeathText2;
        private Text DeathText3;
        private Text DeathScore;
        public int score;
        private int health;
        private const int FontSize = 18;
        private const int Margin = 10;
        private const int DeathFontSize = 25;
        private bool playerAlive;
        public ScreenText(Font font)
        {
            ScoreText = new Text("", font, FontSize);
            HealthText = new Text("", font, FontSize);
            DeathText1 = new Text("", font, DeathFontSize);
            DeathText2 = new Text("", font, DeathFontSize);
            DeathText3 = new Text("", font, DeathFontSize);
            DeathScore = new Text("", font, DeathFontSize);
        }
        public void playerStatus(bool status)
        {
            playerAlive = status;
        }
        public void IncreaseScore(int score)
        {
            this.score += score;
        }
        public void UpdateHealth(int health)
        {
            this.health = health;
        }
        public void Reset()
        {
            score = 0;
        }
        public void UpdateText()
        {
            ScoreText.DisplayedString = $"Score {score}";
            ScoreText.Position = new Vector2f(Program.ScreenW - Margin, Margin);
            ScoreText.Origin = new Vector2f(ScoreText.GetLocalBounds().Width, 0);

            HealthText.DisplayedString = $"Lives {health}";
            HealthText.Position = new Vector2f(Margin, Margin);
            HealthText.Origin = new Vector2f(0, 0);
        }
        public void UpdateDeathText()
        {
            DeathText1.DisplayedString = $"Your final score was {score}";
            DeathText1.Position = new Vector2f(Program.ScreenW / 2, Program.ScreenH / 2);
            DeathText1.Origin = new Vector2f(DeathText1.GetLocalBounds().Width / 2, DeathText1.GetLocalBounds().Height / 2);

            DeathText2.DisplayedString = "press R to try again or E to exit";
            DeathText2.Position = new Vector2f(Program.ScreenW / 2, (Program.ScreenH / 2) + 25);
            DeathText2.Origin = new Vector2f(DeathText2.GetLocalBounds().Width / 2, DeathText2.GetLocalBounds().Height / 2);

            DeathText3.DisplayedString = "or M to go to the menu";
            DeathText3.Position = new Vector2f(Program.ScreenW / 2, (Program.ScreenH / 2) + 50);
            DeathText3.Origin = new Vector2f(DeathText3.GetLocalBounds().Width / 2, DeathText3.GetLocalBounds().Height / 2);
        }
        public void HighestScore(int highest)
        {
            if (score < highest)
            {
                DeathScore.DisplayedString = $"The highest score is {highest}";
            }
            else
            {
                DeathScore.DisplayedString = $"The highest score is now {score}";
            }
            DeathScore.Position = new Vector2f(Program.ScreenW / 2, Program.ScreenH / 2 - 50);
            DeathScore.Origin = new Vector2f(DeathScore.GetLocalBounds().Width / 2, DeathScore.GetLocalBounds().Height / 2);
        }
        public void RenderText(RenderTarget target)
        {
            if (playerAlive)
            {
                target.Draw(ScoreText);
                target.Draw(HealthText);
            }
            else
            {
                target.Draw(DeathText1);
                target.Draw(DeathText2);
                target.Draw(DeathText3);
                target.Draw(DeathScore);
            }
        }
    }
}
