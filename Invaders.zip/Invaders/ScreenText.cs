﻿using System;
using System.Collections.Generic;
using System.Text;
using SFML.Graphics;
using SFML.System;
using SFML.Window;

namespace Invaders
{
    class ScreenText : Entity
    {
        private Text ScoreText;
        private Text HealthText;
        private Text DeathText;
        private int score;
        private int health;
        private const int FontSize = 18;
        private const int Margin = 10;
        private const int DeathFontSize = 25;
        private bool playerAlive;
        public ScreenText(Font font)
        {
            ScoreText = new Text("", font, FontSize);
            HealthText = new Text("", font, FontSize);
            DeathText = new Text("", font, DeathFontSize);
            UpdateText();
        }
        public void playerStatus(bool status)
        {
            playerAlive = status;
        }
        public void IncreaseScore(int score)
        {
            this.score += score;
            UpdateText();
        }
        public void UpdateHealth(int health)
        {
            this.health = health;
        }
        public void UpdateText()
        {
            ScoreText.DisplayedString = $"Score {score}";
            ScoreText.Position = new Vector2f(Program.ScreenW - Margin, Margin);
            ScoreText.Origin = new Vector2f(ScoreText.GetLocalBounds().Width, 0);

            HealthText.DisplayedString = $"Lives {health}";
            HealthText.Position = new Vector2f(Margin, Margin);
            HealthText.Origin = new Vector2f(0, 0);

            DeathText.DisplayedString = $"Your final score was {score}, press R to try again or E to exit.";
            DeathText.Position = new Vector2f(Program.ScreenW / 2, Program.ScreenH / 2);
            DeathText.Origin = new Vector2f(DeathText.GetLocalBounds().Width / 2, DeathText.GetLocalBounds().Height / 2);
        }
        //public void DeathScreenText()
        //{
        //    DeathText.DisplayedString = $"Your final score was {score}, press R to try again or E to exit.";
        //    DeathText.Position = new Vector2f(Program.ScreenW / 2, Program.ScreenH / 2);
        //    DeathText.Origin = new Vector2f(DeathText.GetLocalBounds().Width / 2, DeathText.GetLocalBounds().Height / 2);
        //}
        public override void Render(RenderTarget target)
        {
            if (playerAlive)
            {
                target.Draw(ScoreText);
                target.Draw(HealthText);
            }
            else
            {
                target.Draw(DeathText);
            }
        }
    }
}
