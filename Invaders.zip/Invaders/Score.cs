﻿using System;
using System.Collections.Generic;
using System.Text;
using SFML.Graphics;
using SFML.System;
using SFML.Window;

namespace Invaders
{
    class Score : Entity
    {
        private Text ScoreText;
        private int score;
        private const int FontSize = 18;
        private const int Margin = 20;
        public Score(Font font)
        {
            ScoreText = new Text("", font, FontSize);
            UpdateText();
        }
        public void IncreaseScore(int score)
        {
            this.score += score;
            UpdateText();
        }
        public void UpdateText()
        {
            ScoreText.DisplayedString = $"Score {score}";
            ScoreText.Position = new Vector2f(Program.ScreenW - Margin, Margin);
            ScoreText.Origin = new Vector2f(ScoreText.GetLocalBounds().Width, 0);
        }
        public override void Render(RenderTarget target)
        {
            target.Draw(ScoreText);
        }
    }
}
