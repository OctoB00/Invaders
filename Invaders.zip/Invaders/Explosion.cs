﻿using System;
using System.Collections.Generic;
using System.Text;
using SFML.Graphics;
using SFML.System;
using SFML.Window;

namespace Invaders
{
    public class Explosion : Entity
    {
        private readonly Sprite sprite;
        private Clock frameClock = new Clock();
        private IntRect frameRect = new IntRect(0, 0, 70, 67);
        public Explosion()
        {
            sprite = new Sprite();
        }
        public override void Load(Textures textures)
        {
            sprite.Texture = textures.GetTexture("Explosion.png");
            sprite.TextureRect = frameRect;
            sprite.Origin = new Vector2f(sprite.TextureRect.Width * 0.5f, sprite.TextureRect.Height * 0.5f);
        }
        public override void Update(Game game, float deltaTime)
        {
            if (frameClock.ElapsedTime.AsSeconds() > 0.08f)
            {
                frameRect.Top += 67;
                sprite.TextureRect = frameRect;
                frameClock.Restart();
            }
            if (frameRect.Top == 469)
            {
                game.Kill(this);
            }
        }
        public override Vector2f Position 
        {
            get => sprite.Position; 
            set => sprite.Position = value; 
        }
        public override void Render(RenderTarget target)
        {
            target.Draw(sprite);
        }
    }
}
