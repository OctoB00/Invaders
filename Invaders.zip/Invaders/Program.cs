﻿using System;
using SFML.Graphics;
using SFML.System;
using SFML.Window;

namespace Invaders
{
    public class Program
    {
        public const int ScreenW = 500;
        public const int ScreenH = 1000;
        private const int enemyWidth = 50;
        static void Main(string[] args)
        {
            bool gamestart = true;
            bool isAlive = true;
            using (var window = new RenderWindow(new VideoMode(ScreenW, ScreenH), "Invaders"))
            {
                window.Closed += (s, e) => window.Close();
                Clock frameclock = new Clock();
                Clock DifficultyTimer = new Clock();
                Clock spawnTimer = new Clock();
                float spawnEnemy = 3f;
                bool spawn2Enemies = false;
                bool checktimer = true;
                int enemiesSpawned = 1;
                Clock scoreTimer = new Clock();
                Random random = new Random();
                float enemySpeedX;
                ScreenText text = new ScreenText(new Font("ARCADECLASSIC.TTF"));
                Playership player = new Playership()
                {
                    //Velocity = new Vector2f(0, 0),
                    Position = new Vector2f(ScreenW / 2, ScreenH / 2)
                };
                Game game = new Game(window);
                while (window.IsOpen)
                {
                    window.DispatchEvents();
                    window.Clear(new Color(0, 0, 0));
                    float deltaTime = frameclock.Restart().AsSeconds();
                    game.RenderAll(window);
                    if (isAlive)
                    {
                        if (gamestart)
                        {
                            game.Spawn(player);
                            game.Spawn(text);
                            gamestart = false;
                        }
                        if (spawnTimer.ElapsedTime.AsSeconds() > spawnEnemy)
                        {
                            if (random.Next(1, 2 + 1) == 1) enemySpeedX = 75f;
                            else enemySpeedX = -75f;
                            spawnTimer.Restart();
                            for (int i = 0; i < enemiesSpawned; i++)
                            {
                                game.Spawn(new EnemyShip()
                                {
                                    Position = new Vector2f(random.Next(enemyWidth, ScreenW - enemyWidth), 0),
                                    Velocity = new Vector2f(enemySpeedX, 150)
                                    //Rotation = 75
                                });
                            }
                        }
                        if (DifficultyTimer.ElapsedTime.AsSeconds() >= 10f && spawnEnemy > 1.1f)
                        {
                            DifficultyTimer.Restart();
                            spawnEnemy--;
                        }
                        if (checktimer && DifficultyTimer.ElapsedTime.AsSeconds() >= 10f)
                        {
                            spawn2Enemies = true;
                            checktimer = false;
                        }
                        if (spawn2Enemies)
                        {
                            enemiesSpawned = 2;
                        }
                        if (player.HasShot())
                        {
                            player.Shoot(game);
                        }
                        if (scoreTimer.ElapsedTime.AsSeconds() >= 0.5f)
                        {
                            scoreTimer.Restart();
                            text.IncreaseScore(1);
                        }
                        if (player.health == 0)
                        {
                            isAlive = false;
                        }
                        text.UpdateHealth(player.health);
                        text.playerStatus(isAlive);
                    }
                    else
                    {
                        game.Clear();
                        game.Spawn(text);
                    }
                    game.UpdateAll(deltaTime);

                    window.Display();
                }
            }
        }
    }
}
//explostion
//class Explosion : Entity
//{
//    private readonly Sprite sprite;
//    private Clock animationClock = new Clock();
//    private IntRect animationrect = new IntRect(0, 0, 200, 200);

//    public Explosion()
//    {
//        sprite = new Sprite(); //PÅ ICA MAXI BORÅS KAN DU FÅ EN 2 LITERS FÖR BARA 21,50 KR, DU KAN TILLOCHMED FÅ DEN HEMLEVEREAD FÖR BARA YNKA 129SEK. KÖP IDAG! OCH FÅ IGÅR! INTE SPONSRAD MEN UTTRÅKAD KANSKE LITE SPONSRAD DÅ... MEN INTE MYCKET


//    }

//    public override void Load(Asset asset)
//    {
//        sprite.Texture = asset.GetTexture("ExplosionSpriteSheet.png");
//        sprite.TextureRect = animationrect;
//        sprite.Origin = new Vector2f(sprite.TextureRect.Width * 0.5f, sprite.TextureRect.Height * 0.5f);
//        //  base.Load(asset);
//    }

//    public override void Update(Scene scene, float deltaTime)
//    {

//        if (animationClock.ElapsedTime.AsSeconds() > 0.05f)
//        {
//            animationrect.Left += 200;
//            sprite.TextureRect = animationrect;
//            animationClock.Restart();

//        }
//        if (animationrect.Left == 1600)
//            scene.Destroy(this);


//        base.Update(scene, deltaTime);
//    }


//    public override Vector2f Position
//    {
//        get => sprite.Position;
//        set => sprite.Position = value;
//    }

//    // public override float Radius => MathF.Max(sprite.Origin.X, sprite.Origin.Y);


//    public override void Render(RenderTarget target)
//    {

//        target.Draw(sprite);
//        base.Render(target);
//    }
//}
