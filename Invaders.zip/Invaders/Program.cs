﻿using System;
using SFML.Graphics;
using SFML.System;
using SFML.Window;

namespace Invaders
{
    public class Program
    {
        public const int ScreenW = 500;
        public const int ScreenH = 1000;
        private const int enemyWidth = 50;
        static void Main(string[] args)
        {
            bool gamestart = true;
            using (var window = new RenderWindow(new VideoMode(ScreenW, ScreenH), "Invaders"))
            {
                window.Closed += (s, e) => window.Close();
                Clock frameclock = new Clock();
                Clock spawnTimer = new Clock();
                float spawnEnemy = 3f;
                Random random = new Random();
                int enemyspeedX = 50;
                int enemyspeedY = 100;
                Playership player = new Playership()
                {
                    //Velocity = new Vector2f(0, 0),
                    Position = new Vector2f(ScreenW / 2, ScreenH / 2)
                };
                Game game = new Game(window);
                while (window.IsOpen)
                {
                    window.DispatchEvents();
                    window.Clear(new Color(0, 0, 0));
                    float deltaTime = frameclock.Restart().AsSeconds();
                    game.RenderAll(window);
                    if (gamestart)
                    {
                        game.Spawn(player);
                        gamestart = false;
                    }
                    if (spawnTimer.ElapsedTime.AsSeconds() > spawnEnemy)
                    {
                        spawnTimer.Restart();
                        game.Spawn(new EnemyShip()
                        {
                            Position = new Vector2f(random.Next(enemyWidth, ScreenW - enemyWidth), 0),
                            Velocity = new Vector2f(50, 100)
                            //Rotation = 75
                        });
                    }
                    if (player.HasShot())
                    {
                        player.Shoot(game);
                    }
                    //if (enemy.HasShot())
                    //{
                    //    enemy.Shoot(game);
                    //}
                    game.UpdateAll(deltaTime);

                    window.Display();
                }
            }
        }
    }
}
