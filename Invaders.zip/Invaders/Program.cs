﻿using System;
using SFML.Graphics;
using SFML.System;
using SFML.Window;

namespace Invaders
{
    public class Program
    {
        public const int ScreenW = 500;
        public const int ScreenH = 1000;
        private const int enemyWidth = 50;
        
        static void Main(string[] args)
        {
            bool gamestart = true;
            bool gamePlaying = false;
            bool menuOpen = true;
            bool HighScoreOpen = false;
            bool ScoreWritten = false;
            using (var window = new RenderWindow(new VideoMode(ScreenW, ScreenH), "Invaders"))
            {
                window.Closed += (s, e) => window.Close();
                Clocks clocks = new Clocks();
                Clock frameclock = new Clock();
                float spawnEnemy = 3f;
                bool spawn2Enemies = false;
                bool checktimer = true;
                int enemiesSpawned = 1;
                HighScore highscores = new HighScore();
                Random random = new Random();
                float enemySpeedX;
                ScreenText text = new ScreenText(new Font("ARCADECLASSIC.TTF"));
                Playership player = new Playership()
                {
                    Position = new Vector2f(ScreenW / 2, ScreenH / 2)
                };
                Game game = new Game(window);
                Menu menu = new Menu(new Font("ARCADECLASSIC.TTF"));
                HighScoreMenu scoreMenu = new HighScoreMenu(new Font("ARCADECLASSIC.TTF"));
                while (window.IsOpen)
                {
                    window.DispatchEvents();
                    window.Clear(new Color(0, 0, 0));
                    float deltaTime = frameclock.Restart().AsSeconds();
                    game.RenderAll(window);
                    if (menuOpen && HighScoreOpen == false)
                    {
                        menu.OnMenuSpawn(window);
                        menu.UpdateMenu();
                        switch (menu.MenuSelect())
                        {
                            case 1: menuOpen = false; menu.OnMenuDespawn(window); gamePlaying = true; break;
                            case 2: HighScoreOpen = true; menu.OnMenuDespawn(window); break;
                            case 3: window.Close(); break;
                            case 4: break;
                        }
                        menu.RenderMenu(window);
                    }
                    else if (menuOpen && HighScoreOpen)
                    {
                        scoreMenu.OnScoreMenuSpawn(window);
                        scoreMenu.HighScoreText(highscores.Read(), window);
                        if (scoreMenu.ToMenu() == true)
                        {
                            HighScoreOpen = false;
                            scoreMenu.OnScoreMenuDespawn(window);
                        }
                    }
                    else if (gamePlaying && menuOpen == false)
                    {
                        if (gamestart)
                        {
                            game.Spawn(player);
                            gamestart = false;
                            clocks.Start();
                        }
                        if (clocks.spawnTimer.ElapsedTime.AsSeconds() > spawnEnemy)
                        {
                            if (random.Next(1, 2 + 1) == 1) enemySpeedX = 75f;
                            else enemySpeedX = -75f;
                            clocks.spawnTimer.Restart();
                            for (int i = 0; i < enemiesSpawned; i++)
                            {
                                game.Spawn(new EnemyShip()
                                {
                                    Position = new Vector2f(random.Next(enemyWidth, ScreenW - enemyWidth), 0),
                                    Velocity = new Vector2f(enemySpeedX, 150)
                                });
                            }
                        }
                        if (clocks.DifficultyTimer.ElapsedTime.AsSeconds() >= 10f && spawnEnemy > 1.1f)
                        {
                            clocks.DifficultyTimer.Restart();
                            spawnEnemy--;
                        }
                        if (checktimer && clocks.DifficultyTimer.ElapsedTime.AsSeconds() >= 10f)
                        {
                            spawn2Enemies = true;
                            checktimer = false;
                        }
                        if (spawn2Enemies)
                        {
                            enemiesSpawned = 2;
                        }
                        if (player.HasShot())
                        {
                            player.Shoot(game);
                        }
                        if (clocks.scoreTimer.ElapsedTime.AsSeconds() >= 0.5f)
                        {
                            clocks.scoreTimer.Restart();
                            text.IncreaseScore(1);
                        }
                        if (player.health == 0)
                        {
                            gamePlaying = false;
                        }
                        text.UpdateText();
                        text.UpdateHealth(player.health);
                        text.playerStatus(gamePlaying);
                        text.RenderText(window);
                    }
                    else if (gamePlaying == false && menuOpen == false)
                    {
                        game.Clear();
                        window.KeyPressed += (s, e) =>
                        {
                            switch (e.Code)
                            {
                                case Keyboard.Key.R: gamePlaying = true; gamestart = true; player.health = 3; text.Reset(); spawnEnemy = 3f; spawn2Enemies = false; enemiesSpawned = 1; player = new Playership() { Position = new Vector2f(ScreenW / 2, ScreenH / 2) }; checktimer = true; ScoreWritten = false; break;
                                case Keyboard.Key.E: window.Close(); break;
                                case Keyboard.Key.M: menuOpen = true; player.health = 3; text.Reset(); spawnEnemy = 3f; spawn2Enemies = false; checktimer = true; ScoreWritten = false; gamestart = true; player = new Playership() { Position = new Vector2f(ScreenW / 2, ScreenH / 2) }; break;
                            }
                        };
                        text.UpdateDeathText();
                        text.HighestScore(scoreMenu.GetHighestScore(highscores.Read()));
                        text.RenderText(window);
                        if (ScoreWritten == false)
                        {
                            highscores.Write(text.score.ToString());
                            ScoreWritten = true;
                        }
                    }
                    game.UpdateAll(deltaTime);

                    window.Display();
                }
            }
        }
    }
}
