﻿using System;
using System.Collections.Generic;
using System.Text;
using SFML.Graphics;
using SFML.System;
using SFML.Window;
using SFML.Audio;

namespace Invaders
{
    public class Playership : Entity
    {
        private readonly Sprite sprite;
        private bool moveRight, moveLeft, moveUp, moveDown, shoot;
        private Vector2f Direction;
        private Vector2f newPosition;
        private const float speed = 250;
        private const float Reloadime = 0.5f;
        private Vector2f BulletSpeed = new Vector2f(0, -400);
        public int health = 3;
        private const float immortalTime = 2f;
        private Clock immortalTimer = new Clock();
        private Color immortalColor;
        SoundBuffer pew;
        Sound sound;
        private bool Immortal => immortalTimer.ElapsedTime.AsSeconds() < immortalTime;
        
        public Playership()
        {
            sprite = new Sprite();
            pew = new SoundBuffer("laserSmall_002.ogg");
            sound = new Sound(pew);
        }
        public override void Load(Textures textures)
        {
            sprite.Texture = textures.GetTexture("Playership.png");
            sprite.Origin = (Vector2f)sprite.Texture.Size * 0.5f;
        }
        public override float Radius => MathF.Max(sprite.Origin.X, sprite.Origin.Y);
        public override Vector2f Position
        {
            get => sprite.Position;
            set => sprite.Position = value;
        }
        private void OnKeyPressed(object sender, KeyEventArgs e)
        {
            switch (e.Code)
            {
                case Keyboard.Key.Left: moveLeft = true; break;
                case Keyboard.Key.Right: moveRight = true; break;
                case Keyboard.Key.Up: moveUp = true; break;
                case Keyboard.Key.Down: moveDown = true; break;
                case Keyboard.Key.Space: shoot = true; break;
            }
        }
        private void OnKeyReleased(object sender, KeyEventArgs e)
        {
            switch (e.Code)
            {
                case Keyboard.Key.Left: moveLeft = false; break;
                case Keyboard.Key.Right: moveRight = false; break;
                case Keyboard.Key.Up: moveUp = false; break;
                case Keyboard.Key.Down: moveDown = false; break;
                case Keyboard.Key.Space: shoot = false; break;
            }
        }
        public override void OnSpawn(Window w)
        {
            w.KeyPressed += OnKeyPressed;
            w.KeyReleased += OnKeyReleased;
        }
        public override void OnDespawn(Window w)
        {
            w.KeyPressed -= OnKeyPressed;
            w.KeyReleased -= OnKeyReleased;
        }
        public bool HasShot()
        {
            if (shoot)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private Clock shootTimer = new Clock();
        public void Shoot(Game game)
        {
            if (shootTimer.ElapsedTime.AsSeconds() > Reloadime)
            {
                sound.Play();
                shootTimer.Restart();
                game.Spawn(new Bullet()
                {
                    Position = this.Position,
                    Velocity = BulletSpeed,
                    Rotation = -90,
                    IsHostile = false,
                    color = Color.White
                });
            }
        }
        public override void CollideWith(Game game, Entity other)
        {
            if (other is Bullet bul && bul.IsHostile == true && !Immortal)
            {
                immortalTimer.Restart();
                game.Kill(bul);
                health--;
            }
            else if (other is EnemyShip enemy && !Immortal)
            {
                game.Spawn(new Explosion()
                {
                    Position = enemy.Position
                });
                immortalTimer.Restart();
                game.Kill(enemy);
                health--;
            }
        }
        public override void Update(Game game, float deltaTime)
        {
            newPosition = sprite.Position + Direction * (speed * deltaTime);
            if (moveLeft)
            {
                Direction.X = -1;
            }
            else if (moveRight)
            {
                Direction.X = 1;
            }
            else if (moveUp)
            {
                Direction.Y = -1.5f;
            }
            else if (moveDown)
            {
                Direction.Y = 1.5f;
            }
            else
            {
                Direction = new Vector2f(0, 0);
            }
            if (newPosition.Y + sprite.Origin.Y > Program.ScreenH + 10|| newPosition.Y - sprite.Origin.Y < -10)
            {
                Direction.Y = 0;
            }
            else if (newPosition.X + sprite.Origin.X > Program.ScreenW - 10|| newPosition.X - sprite.Origin.X < 11)
            {
                Direction.X = 0;
            }
            else
            {
                sprite.Position = newPosition;
            }
            if (health == 0)
            {
                game.Kill(this);
            }
            if (Immortal)
            {
                immortalColor = new Color(255, 255, 255, 150);
            }
            else
            {
                immortalColor = Color.White;
            }
        }
        public override void Render(RenderTarget target)
        {
            sprite.Color = immortalColor;
            sprite.Rotation = -90;
            target.Draw(sprite);
        }
    }
}
