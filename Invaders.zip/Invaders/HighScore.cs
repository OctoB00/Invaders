﻿using System;
using System.Collections.Generic;
using System.Text;
using SFML.Graphics;
using SFML.System;
using SFML.Window;
using System.IO;

namespace Invaders
{
    public class HighScore
    {
        public void Write(string save)
        {
            using (StreamWriter sw = new StreamWriter("Highscores.txt", true))
            {
                sw.WriteLine(save);
            }
        }
        public string[] Read()
        {
            return File.ReadAllLines("Highscores.txt");
        }
    }
}

